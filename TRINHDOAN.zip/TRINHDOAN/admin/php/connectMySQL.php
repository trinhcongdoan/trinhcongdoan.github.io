<?php
	$servername = "localhost";
	$username = "doan";
	$password = "";
	$dbname = "login";

	// Create connection
	$conn = new mysqli($servername, $username, $password,$dbname);

?>
